import { test, expect } from '@playwright/test';
import { LoginPage } from '../Pages/loginpage';
import { HomePage } from '../Pages/homepage';

//Login to demo application
test.only("login to application", async ({ page }) => {

    const _LoginPage = new LoginPage(page)
    //Open application
    await _LoginPage.rc_OpenApplication()
    //Login
    await _LoginPage.rc_Login()
    const _HomePage = new HomePage(page)
    await _HomePage.rc_VerifyLoginSuccess()

  });
  