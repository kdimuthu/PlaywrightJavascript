import { test, expect } from '@playwright/test';


//Login to demo application
test.only("login", async ({ page }) => {
  await page.goto("https://demo.guru99.com/test/newtours/index.php");

  //Enter username

  await page.locator('css=input[name="userName"]').fill("kdimuthu");

  //Enter password

  await page.locator('xpath=//input[@name="password"]').fill("Dimuthu@123");

  //Click login
  await page.locator('xpath=//input[@name="submit"]').click();

  //Verify login succuss message

  await expect(page.locator("xpath=//h3")).toHaveText("Login Successfully");
});
