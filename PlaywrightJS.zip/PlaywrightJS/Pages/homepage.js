import { test, expect } from '@playwright/test';

export class HomePage{

    constructor(page) {

        this.page = page
        
        /* ========After Login Section ====================================*/
       
        this.msg_LoginSuccess = page.locator("//h3")

    }

    //Verify login success
    async rc_VerifyLoginSuccess() {

        //Verify login success
        await expect(this.msg_LoginSuccess).toHaveText("Login Successfully");
    }

}
