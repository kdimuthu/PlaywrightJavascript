import { test, expect } from '@playwright/test';

export class LoginPage{

    constructor(page) {

        this.page = page
        
        /* ========Login Section ====================================*/
       
        this.txt_Username = page.locator("input[name='userName']")
        this.txt_Password = page.locator("//input[@name='password']")
        this.btn_Login = page.locator("//input[@name='submit']")

    }

    //Open the application
    async rc_OpenApplication() {

        //Open the application
        await this.page.goto("https://demo.guru99.com/test/newtours/index.php")
    }

    //Login

    async rc_Login() {

        //Enter username
        await this.txt_Username.fill("kdimuthu")
        //Enter password
        await this.txt_Password.fill("Dimuthu@123")
        //Click login
        await this.btn_Login.click()
    }
}
